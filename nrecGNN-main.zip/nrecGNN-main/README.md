For review usesage only, dot not distribute

Two parameters. The first is dimension embedding and the other is dropnode.
